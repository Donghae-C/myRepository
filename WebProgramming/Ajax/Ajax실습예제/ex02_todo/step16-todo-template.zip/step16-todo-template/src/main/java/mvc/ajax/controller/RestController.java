package mvc.ajax.controller;


/**
 * 비동기통신을 위한 Controller
 * */
public interface RestController {
    
}
