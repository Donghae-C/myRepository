package ex0926.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ex0926.dto.MemberDTO;
import ex0926.util.DbUtil;

public class MemberDaoImpl implements MemberDAO {

	@Override
	public List<MemberDTO> selectAll() throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<MemberDTO> memberList = new ArrayList<MemberDTO>();
		String sql = "select id,pwd,name, age, phone, addr, join_date from member order by join_date desc";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			if(rs.next()) {
				MemberDTO member = new MemberDTO(rs.getString("id"),
						rs.getString("pwd"),
						rs.getString("name"),
						rs.getInt("age"), 
						rs.getString("phone"), 
						rs.getString("addr"), 
						rs.getString("join_date"));
				memberList.add(member);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbUtil.dbClose(rs, ps, con);
		}
		return memberList;
	}

	@Override
	public int insert(MemberDTO member) {
		Connection con = null;
		PreparedStatement ps = null;
		int result = 0;
		String sql = "insert into member(id,pwd,name,age,phone,addr, join_date) values(?,?,?,?,?,?, now())";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, member.getId());
			ps.setString(2, member.getPwd());
			ps.setString(3, member.getName());
			ps.setInt(4, member.getAge());
			ps.setString(5, member.getPhone());
			ps.setString(6, member.getAddr());
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbUtil.dbClose(ps, con);
		}
		return result;
	}

	@Override
	public MemberDTO getSelectById(String id) {

		return null;
	}

	@Override
	public int delete(String id) {

		return 0;
	}

	@Override
	public int update(MemberDTO memberDTO) {

		return 0;
	}

	@Override
	public List<MemberDTO> findBykeyFieldWord(String keyField, String keyWord) {

		return null;
	}

}
