package ex0926.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

import ex0926.dao.MemberDAO;
import ex0926.dao.MemberDaoImpl;
import ex0926.dto.MemberDTO;

/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("/selectAll")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private final MemberDAO memberDAO = new MemberDaoImpl();
    public MemberServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<MemberDTO> memberList = memberDAO.selectAll();
			request.setAttribute("memberList", memberList);
			request.getRequestDispatcher("/memberSelect.jsp").forward(request, response);
			String joinDate = LocalDateTime.now().toString();
			System.out.println(joinDate);
		} catch (SQLException e) {
			request.setAttribute("errMsg", "문제가..");
			request.getRequestDispatcher("/error.jsp").forward(request, response);
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
